p = input("pricipal:")
t = input("time:")
r = input("rate:")
si = (int(p)*int(t)*int(r))/100
print(si)