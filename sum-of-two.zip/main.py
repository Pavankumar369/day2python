a = input("enter the first number:")
b = input("enter the second number:")
c = int(a)+int(b)
print(c)