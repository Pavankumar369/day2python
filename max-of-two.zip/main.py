a = input("first:")
b = input("second:")
if(a>=b):
    print("max is",a)
else:
    print("max is",b)